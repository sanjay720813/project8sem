	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
<li><a href="#"><i class="fa fa-files-o"></i> Blood Group</a>
<ul>
<li><a href="add-bloodgroup.php">Add Blood Group</a></li>
<li><a href="manage-bloodgroup.php">Manage Blood Group</a></li>
</ul>
</li>


				<li><a href="add-donor.php"><i class="fa fa-edit"></i> Add Donor</a></li>
				<li><a href="donor-list.php"><i class="fa fa-users"></i> Donor List</a></li>

				<li><a href="manage-conactusquery.php"><i class="fa fa-desktop""></i> Manage Conatctus Query</a></li>
			<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li>
			<li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i> Update Contact Info</a></li>


			</ul>
		</nav>